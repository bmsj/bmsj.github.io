TITLE:	NewGamePlus [SF]
曲URL:	http://www1.axfc.net/u/3634678
LEVEL:	★1...??? (so1?)

for 「Genocide Reinterpretation 2」
Original Sabun: ★1 NewGamePlus [Good old game]

동봉 ANOTHER 기준이지만, 키음 추가 커팅으로 인한 엇갈림이 있습니다.
同梱ANOTHER基準ですが、キー音追加カットによるズレがあります。

LN과 너무 잘 어울리는 곡이라서 만들어봤습니다. (동봉패턴도 LN을 적극적으로 쓰고 있네요!)
너무 열심히(?) 만들어서 원본 발광패턴은 흔적도 안 남아있고, 난이도도 ★로 매기기 곤란한 지경이 됐습니다만...
재밌으니까 됐다 그죠?

2026.2.16	seojoon